import { Component } from '@angular/core';

/**
 * Generated class for the CachePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'figure-demo',
  templateUrl: 'figure.html',
})
export class FigureDemo {
  constructor() {}
  ionViewDidLoad() {
    console.log('ionViewDidLoad CachePage');
  }

}
