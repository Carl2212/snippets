import { Component, ViewChild, Renderer2, Input } from '@angular/core';
import { NavController, Gesture, Platform } from 'ionic-angular';
import { ToolsService, ActionStruct, lineStatus, point, textStatus, rectStatus, circleStatus } from "../tools/tools.service";
import { UIEventManager } from "ionic-angular/es2015/gestures/ui-event-manager";

export function getOffset(event : any) {
  if(event) {
    console.log(event);
    let changedTouches = event.changedTouches;
    if(changedTouches && changedTouches.length > 0) {
      let touch= changedTouches[0];
      return {x: touch.clientX, y: touch.clientY};
    }
    var pageX = event.pageX;
    if(pageX != undefined) {
      return {x: pageX, y: event.pageY};
    }
  }
  return {x : 0, y: 0}
}

@Component({
  selector: 'canvas-comp',
  templateUrl: 'canvas.html'
})
export class Canvas {

  @ViewChild('canvas') canvas;
  @ViewChild('dragBox') dragBox;
  @ViewChild('pointLayer') pointLayer;
  @ViewChild('textArea') textArea;
  cs : any;

  private _iHeight : number;
  private events: UIEventManager
  @Input() imageUrl : string;
  @Input() iWidth : number;
  @Input()
  set iHeight(val : number) {
    this._iHeight = val;
    if(this._iHeight) {
      this.initCanvas();
    }
  }
  get iHeight() : number {
    return this._iHeight;
  }
  constructor(
    public navCtrl: NavController,
    private render : Renderer2,
    private tool: ToolsService,
    private plt: Platform

  ) {
  }
  initCanvas() {
    let devicePixelRatio = window.devicePixelRatio || 1;
    this.cs = this.canvas.nativeElement.getContext('2d');
    this.render.setStyle(this.canvas.nativeElement,'width',`${this.iWidth}px`);
    this.render.setStyle(this.canvas.nativeElement,'height',`${this.iHeight}px`);
    this.canvas.nativeElement.height = this.iHeight * devicePixelRatio;
    this.canvas.nativeElement.width = this.iWidth * devicePixelRatio;
    this.cs.scale(devicePixelRatio , devicePixelRatio);
    let image = new Image();
    image.onload = ()=>{
      this.cs.drawImage(image,0,0,this.iWidth,this.iHeight);
      this.gestureEvent();
    }
    image.src = this.imageUrl;
  }
  gestureEvent() {
    this.events = new UIEventManager(this.plt);
    this.events.pointerEvents({
      element: this.pointLayer.nativeElement,
      pointerDown: this.onDrawStart.bind(this),
      pointerMove: this.onDraw.bind(this),
      pointerUp: this.onDrawEnd.bind(this)
    });
  }
  onDrawStart(ev) {
    let offset = this.offsetFormat(getOffset(ev));
    this.cs.strokeStyle= this.tool.color;
    this.cs.lineWidth = this.tool.lineWidth;
    this.cs.beginPath();
    this.cs.moveTo(offset.x , offset.y);
    this.cs.lineTo(offset.x , offset.y);
    this.cs.stroke();
    return true;
  }
  onDraw(ev) {
    let offset = this.offsetFormat(getOffset(ev));
    this.cs.lineTo(offset.x , offset.y);
    this.cs.stroke();
  }
  onDrawEnd(ev) {
    let offset = this.offsetFormat(getOffset(ev));
    this.cs.lineTo(offset.x , offset.y);
    this.cs.stroke();
    this.cs.closePath();
  }
  offsetFormat(ev) {
    console.log(ev,this.tool.canvasLeft,this.tool.canvasTop);
    if(ev) {
      return {x: ev.x - this.tool.canvasLeft ,y: ev.y - this.tool.canvasTop};
    }
    return {x: 0 ,y: 0}
  }
  drawLine(l: lineStatus) {
    if(l.pointGroup.length > 0) {
      this.cs.save();
      this.cs.strokeStyle = l.color;
      this.cs.lineWidth = l.lineWidth;
      this.cs.beginPath();
      this.cs.moveTo(l.pointGroup[0].x,l.pointGroup[0].y);
      l.pointGroup.forEach((p: point)=>{
        this.cs.lineTo(p.x,p.y);
      })
      this.cs.stroke();
      this.cs.closePath();
      this.cs.restore();
    }
  }

  drawText(t:textStatus) {
    this.cs.save();
    this.cs.font = t.font+'px';
    this.cs.fillStyle = t.color;
    this.cs.fillText(t.content,t.boxLeft,t.boxTop,t.boxWidth);
    this.cs.restore();
  }

  drawRect(r: rectStatus) {
    this.cs.save();
    this.cs.fillStyle = r.color;
    this.cs.lineWidth = r.lineWidth;
    this.cs.fillRect(r.point.x,r.point.y,r.width,r.height);
    this.cs.stroke();
    this.cs.restore();
  }

  drawCircle(c: circleStatus) {
    this.cs.save();
    this.cs.fillStyle = c.color;
    this.cs.lineWidth = c.lineWidth;
    this.cs.arc(c.point.x,c.point.y,c.radius);
    this.cs.stroke();
    this.cs.restore();
  }


}

