import { Component, ViewChild, Renderer2, Output, EventEmitter } from "@angular/core";
import { ToolsService } from "../tools/tools.service";
import { Gesture, Platform } from "ionic-angular";
import { getOffset } from "../canvas/canvas";
import { UIEventManager } from "ionic-angular/gestures/ui-event-manager";
@Component({
  selector : 'dragbox',
  template : `
    <div class="drag-box" #dragBox>
     <span #scaleLeft id="scaleLeft" class="point left" (tap)="setScale('left')" tappable></span>
     <span #scaleRight id="scaleRight" class="point right" (tap)="setScale('right')" tappable></span>
     
     <ng-content></ng-content>
    </div>
  `
})
export class DragBox {

  @ViewChild('dragBox') dragBox;
  @ViewChild('scaleRight') scaleRight;
  @ViewChild('scaleLeft') scaleLeft;
  public gap : {gapX: number; gapY: number};
  scale : string;
  @Output('drag') drag= new EventEmitter<any>();
  private events: UIEventManager
  constructor(
    private render : Renderer2,
    private tool : ToolsService,
    private plt: Platform
  ){}
  init() {
    this.tool.boxLeft = 100;
    this.tool.boxTop = 200;
    this.tool.boxWidth = 200;
    this.renderer();
  }
  ngAfterViewInit() {
    this.init();
    this.events = new UIEventManager(this.plt);
    this.events.pointerEvents({
      element: this.dragBox.nativeElement,
      pointerDown: this.onDragStart.bind(this),
      pointerMove: this.onDragMove.bind(this),
      pointerUp: this.onDragEnd.bind(this)
    });
  }
  onDragMove(e) {
    let offset =  getOffset(e);
    if(!this.scale){
      this.tool.boxLeft = offset.x - this.gap.gapX;
      this.tool.boxTop = offset.y - this.gap.gapY;
      this.renderer();
    }else{
      switch (this.scale) {
        case 'right':
          this.tool.boxWidth = offset.x - this.tool.boxLeft;
          this.renderer();
          break;
        case 'left':
          let change = this.tool.boxLeft - offset.x;
          this.tool.boxWidth= this.tool.boxWidth+ change;
          this.tool.boxLeft= offset.x;

          this.renderer();
          this.tool.boxLeft = offset.x;
          break;
        default:
          break;
      }
    }
  }
  setScale(dir: string) {
    this.scale = dir;
  }
  renderer() {
    if(this.tool.boxTop) {
      this.render.setStyle(this.dragBox.nativeElement,'top',`${this.tool.boxTop}px`);
    }
    if(this.tool.boxLeft) {
      this.render.setStyle(this.dragBox.nativeElement,'left',`${this.tool.boxLeft}px`);
    }
    if(this.tool.boxHeight) {
      this.render.setStyle(this.dragBox.nativeElement,'height',`${this.tool.boxHeight}px`);
    }
    if(this.tool.boxWidth) {
      this.render.setStyle(this.dragBox.nativeElement,'width',`${this.tool.boxWidth}px`);
    }
  }
  onDragStart(e) {
    if(e.target.id == 'scaleLeft') {
      this.setScale('left');
    }else if(e.target.id == 'scaleRight'){
      this.setScale('right');
    }else{
      let offset =  getOffset(e);
      let L = this.dragBox.nativeElement.offsetLeft;
      let T = this.dragBox.nativeElement.offsetTop;
      this.gap = {gapX : offset.x - L , gapY : offset.y - T};
    }
    return true;
  }

  onDragEnd(e) {
    console.log('end');
    this.scale && (this.scale=null);
  }

  getNativeElement() {
    return this.dragBox.nativeElement;
  }
}
