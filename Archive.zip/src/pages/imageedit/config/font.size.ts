/**
 * Created by itwo on 24/5/2018.
 */

export let fontSize=
[15,24,28,30,36,40,48,56,72];
